package java_team_project;

import java.sql.Timestamp;

public class Revision {
    private final long revisionId;
    private final long pageId;
    private final long committedByUserId;
    private final long parentRevisionId;
    private final String commitMessage;
    private final Timestamp createdAt;
    private final long actualDataId;

    public Revision(long revisionId, long pageId, long committedByUserId, long parentRevisionId, String commitMessage, Timestamp createdAt, long actualDataId) {
        this.revisionId = revisionId;
        this.pageId = pageId;
        this.committedByUserId = committedByUserId;
        this.parentRevisionId = parentRevisionId;
        this.commitMessage = commitMessage;
        this.createdAt = createdAt;
        this.actualDataId = actualDataId;
    }

    public long getRevisionId() { return revisionId; }

    public long getPageId() { return pageId; }

    public long getCommittedByUserId() { return committedByUserId; }

    public long getParentRevisionId() { return parentRevisionId; }

    public String getCommitMessage() { return commitMessage; }

    public Timestamp getCreatedAt() { return createdAt; }

    public long getActualDataId() { return actualDataId; }

    @Override
    public String toString() {
        return "Revision{" +
                "RevisionId=" + revisionId +
                ", PageId=" + pageId +
                ", committedByUserId=" + committedByUserId +
                ", parentRevisionId=" + parentRevisionId +
                ", commitMessage='" + commitMessage + '\'' +
                ", CreatedAt=" + createdAt +
                ", actualDataId=" + actualDataId +
                '}';
    }
}
