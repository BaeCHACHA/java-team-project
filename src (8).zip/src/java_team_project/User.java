package java_team_project;

import java.sql.Timestamp;

// DB에 있는 정보 중 password_hash 는 객체에 포함시키지 않는다.
class User {
    private final long userId;
    private final String username;
    private final Timestamp createdAt;

    public User(long userId, String username, Timestamp createdAt) {
        this.userId = userId;
        this.username = username;
        this.createdAt = createdAt;
    }

    public long getUserId() { return userId; }
    public String getUsername() { return username; }
    public Timestamp getCreatedAt() { return createdAt; }

    @Override
    public String toString() {
        return "User{" +
                "userId=" + userId +
                ", username='" + username + '\'' +
                ", createdAt=" + createdAt +
                '}';
    }
}
