package java_team_project;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/*
TODO:
 1. 모든 메소드 -> User 권한 여부 확실하게 체크하고 동작할 수 있도록 (새 Manager 구현 or 메소드에 코드 추가)
 2. PageManager makePage(), deletePage() 로깅 관련 기능 구현하기
 3. PageManager deletePage() 구조 변경 + DB CASCADE DELETE
 4. 메소드 이름 더 명확하게 바꾸기
 5. 주석, javadoc 달기
 6. User <-> Group <-> Page <-> Revision / File : 각 단계에서 이전 단계로 돌아갈 수 있는 기능 구현
 7. !! deletePage() 롤백 오류 발생 !! -> CASCADE DELETE 처리 해줘야할듯? / deletePage() 메소드 일단 호출하지 말 것
 8. 현재 구조는 ID값으로 각 항목들을 선택 / User에게는 이를 노출되게 하지 않으면서 유일한 구분 수단이 필요할 듯 / 새 PK를 추가하거나 GUI 방식 고려 / 임의의 ordering, index 사용?
 9. Application 클래스의 반복되는 형식 -> 클래스 + 상속 구조로 새로 만들어야 할듯
 10. 사용자가 원하는 순서 정렬 시스템 구현 (추가적인 아이디어) (DB 구조 변경 가능성 있음)
 11. revision 기능 관련 추가적인 아이디어 필요
 12. 파일 업로드 / 다운로드 관련 메소드 새롭게 구현 (경로가 아닌 방식으로?) 아이디어 필요
 13. UI에서 파일 수정 기능 구현 (12번 완료한 후!)
 14. 비밀번호 regex 적용할지?
 추가적으로 필요한 메소드는 없는지 확인
 */

/*
TODO: UI에서 할 일
 0. !! BCryptPasswordEncoder 라이브러리 추가, DB랑 연결 잘 되는지 확인 !!
 1. 클래스(인터페이스 + 상속) 형태로 UI를 구현해야 할거같음
    - 메뉴 띄우기 -> 입력받기 -> 실행하기 형태로 구성되어 있음
    - switch-case 문을 클래스처럼 바꾸고 파일 형태로 만드는 방법이 있다던데 조사해봐야 할듯 (모듈화?)
 2. User <-> Group <-> Page <-> Revision / File 각 계층에서 이전/다음 단계로 이동할 수 있도록 구현
 3. 현재 메소드들은 ID값을 파라미터로 전달받는데, 사용자에게는 ID값이 아닌 다른 값(또는 GUI)으로 입력받고, 내부적으로만 ID를 사용하도록 구현 (ID값을 숨겨야 할듯)
 4. revision 관련 아이디어 : 어느 파일로부터 수정된 것인지 표시하려면 어떻게? (지금은 가장 최근 파일로부터 수정된 것으로 표시 중)
 5. 파일 업로드 / 다운로드 관련 메소드 새롭게 구현 (지금은 파일 경로를 입력해서 업로드하는 방식만 가능)
 --- 추가적인 기능 ---
 6. UI에서 파일을 수정한 후 업로드하고 새 revision을 추가하는 기능 (= 파일 수정 기능)
 7. 즐겨찾기 / 오름차순 / 내림차순 등 사용자가 원하는 순서 정렬 시스템 (구현 시 DB 구조 변경 가능성 있음)
 8. revision 그래프 시각화 기능 (구현 시 GUI로 하는 게 좋을듯)
 */

public class Application2 {
    public static void main(String[] args) {

        UserManager userManager = new UserManager();
        User currentUser = null; // 현재 로그인한 사용자

        Scanner scanner = new Scanner(System.in);

        // --- 사용자 로그인/회원가입 메뉴 (기존 코드) ---
        // currentUser에 User 객체를 할당 (로그인)
        int input;
        do {
            System.out.println("--------------");
            System.out.println("1. 회원가입");
            System.out.println("2. 로그인");
            System.out.println("3. 사용자 리스트"); // 예시 메뉴
            System.out.println("0. 종료");
            System.out.println("--------------");
            System.out.print(">> ");

            try {
                input = scanner.nextInt();
            }
            catch (InputMismatchException e) {
                System.out.println("숫자를 입력해주세요.");
                input = -1;
                continue;
            }
            finally {
                scanner.nextLine();
            }

            String id, pw;

            switch (input) {
                case 1:
                    System.out.print("ID를 입력하세요 : ");
                    id = scanner.nextLine();
                    System.out.print("PW를 입력하세요 : ");
                    pw = scanner.nextLine();
                    userManager.addUser(id, pw);
                    break;

                case 2:
                    System.out.print("ID를 입력하세요 : ");
                    id = scanner.nextLine();
                    System.out.print("PW를 입력하세요 : ");
                    pw = scanner.nextLine();
                    currentUser = userManager.login(id, pw);
                    if (currentUser != null) {
                        System.out.println("로그인 성공! 사용자: " + currentUser.getUsername());
                    } else {
                        System.out.println("로그인 실패.");
                    }
                    break;

                case 3:
                    List<User> users = userManager.getAllUsers();
                    if (users.isEmpty()) {
                        System.out.println("등록된 사용자가 없습니다.");
                    } else {
                        System.out.println("--- 사용자 리스트 ---");
                        for (User u : users) {
                            System.out.printf("Username: %s | UserID: %d\n", u.getUsername(), u.getUserId()); // UserID는 long이므로 %d 또는 %s 사용 (long은 %d 출력 포맷 사용)
                        }
                    }
                    break;

                case 0:
                    System.out.println("프로그램을 종료합니다.");
                    break;

                default:
                    System.out.println("다시 입력해주세요.");
            }

        } while (currentUser == null && input != 0); // 로그인 성공하거나 종료할 때까지 반복

        // 사용자가 로그인하지 않고 종료를 선택한 경우
        if (currentUser == null && input == 0) {
            System.out.println("로그인하지 않고 프로그램을 종료합니다.");
            scanner.close();
            return; // 프로그램 종료
        }


        // --- 그룹 및 페이지 관리 메뉴 ---
        // 로그인 성공 시 이 부분 실행
        GroupManager groupManager = new GroupManager(currentUser);
        PageManager pageManager;
        Group currentGroup = null;

        do {
            System.out.println("---------------------------------------------------");
            System.out.println("1. 그룹 만들기");
            System.out.println("2. 그룹 참여");
            System.out.println("3. 그룹 삭제");
            System.out.println("4. 그룹 열기");
            System.out.println("0. 종료");
            System.out.print(">> ");

            try {
                input = scanner.nextInt();
            }
            catch (InputMismatchException e) {
                System.out.println("숫자를 입력해주세요.");
                input = -1;
                continue;
            }
            finally {
                scanner.nextLine();
            }

            String groupName;
            long targetGroupId; // 대상 그룹 ID
            String joinKey;
            List<Membership> membershipList = groupManager.searchGroup();
            Map<Integer, Long> indexToGroupId = new HashMap<>();

            switch (input) {
                case 1:
                    System.out.print("생성할 그룹 이름을 입력하세요 : ");
                    groupName = scanner.nextLine();
                    long createdGroupId = groupManager.makeGroup(groupName); // makeGroup은 long 반환
                    if (createdGroupId != -1) { // -1이 아니라면 성공
                        // 생성된 그룹의 join_key를 표시
                        String createdJoinKey = groupManager.getJoinKey(createdGroupId);
                        if (createdJoinKey != null) {
                            System.out.printf("그룹 생성 성공! 그룹 ID: %d, Join key: %s\n", createdGroupId, createdJoinKey);
                        } else {
                            System.out.printf("그룹 생성 성공! 그룹 ID: %d, Join key 가져오기 실패.\n", createdGroupId);
                        }
                    } else {
                        System.out.println("그룹 생성 실패.");
                    }
                    break;

                case 2:
                    System.out.print("참여할 그룹의 Join key를 입력하세요 : ");
                    joinKey = scanner.nextLine();
                    if (groupManager.joinGroup(joinKey)) { // joinGroup은 boolean 반환
                        System.out.println("그룹 참여에 성공했습니다.");
                    } else {
                        System.out.println("그룹 참여에 실패했습니다. Join key를 확인하세요.");
                    }
                    break;

                case 3: // 그룹 삭제시 해당그룹에 속한 page와 관련내용(revision, file_data) DB에서 삭제필요
                    System.out.print("삭제할 Group ID를 입력하세요 : ");
                    targetGroupId = scanner.nextLong();
                    scanner.nextLine(); // 개행 문자 소비
                    groupManager.deleteGroup(targetGroupId); // deleteGroup은 void 또는 boolean 반환
                    // deleteGroup에서 성공/실패 메시지를 출력한다고 가정
                    break;

                case 4: //group id 랑 membershipList 인덱스 매핑
                	int select;
                	int index = 1;
                    if (membershipList == null || membershipList.isEmpty()) {
                        System.out.println("참여 중인 그룹이 없습니다.");
                    } else {
                        System.out.println("------------------ 참여 중인 그룹 --------------------");
                        for (Membership membership : membershipList) {
                            // 그룹 이름 등 자세한 정보는 selectGroup 등으로 가져와야 함
                        	indexToGroupId.put(index, membership.getGroupId());
                            System.out.printf("%d| Group Name : %s | User ID : %s | User role : %s\n",
                            		index++, groupManager.selectGroup(membership.getGroupId()).getGroupName()
                            		, currentUser.getUsername(), membership.getUserRole());
                        }
                        System.out.println("---------------------------------------------------");
                        
                        System.out.print("그룹을 선택하세요: ");
                    	try {
                            select = scanner.nextInt();
                        }
                        catch (InputMismatchException e) {
                            System.out.println("숫자를 입력해주세요.");
                            select = -1;
                            continue;
                        }
                        finally {
                            scanner.nextLine();
                        }
                    	Long selectedGroupId = indexToGroupId.get(select); // group id랑 index 매핑
                    	if (selectedGroupId != null) {
                    	    targetGroupId = selectedGroupId; // auto-unboxing 안전
                    	} else {
                    	    System.out.println("잘못된 번호입니다.");
                    	    break;
                    	}
                        currentGroup = groupManager.selectGroup(targetGroupId);
                        break;
                    }
                    break;
                case 0:
                    System.out.println("프로그램을 종료합니다.");
                    break;

                default:
                    System.out.println("다른 숫자를 입력하세요.");
            }
        } while ((currentGroup == null) && (input != 0));

        if (currentGroup == null && input == 0) {
            System.out.println("그룹을 열지 않고 프로그램을 종료합니다.");
            scanner.close();
            return; // 프로그램 종료
        }

        pageManager = new PageManager(currentUser, currentGroup);
        long targetPageId = 0;
        List<Revision> revisionList = new ArrayList<>();
        List<Page> pageList = new ArrayList<>();
        Map<Integer, Long> indexToPageId = new HashMap<>();
        Map<Integer, Long> indexToRevisionId = new HashMap<>(); 

        int index;
        do {// page id 내부적으로 사용 pageList의 인덱스 번호랑 매핑
        	index = 1; 
        	pageList = pageManager.searchPage();
        	
        	System.out.printf("\n                    페이지 목록\n");
        	System.out.println("---------------------------------------------------");
            for (Page page : pageList) {
                long pageId = page.getPageId();
                indexToPageId.put(index, pageId);
                String pageName = page.getPageName();
                long latestRevisionId = page.getLatestRevisionId();
                System.out.printf("%d |'%s'| latest revision id: %d\n\n",index++, pageName, latestRevisionId);
            }
            System.out.println("---------------------------------------------------");
            System.out.println("1. 새페이지 만들기");
            System.out.println("2. 페이지 삭제");
            System.out.println("3. 페이지 내용 보기");
            System.out.println("0. 종료");
            System.out.print(">> ");

            try {
                input = scanner.nextInt();
            }
            catch (InputMismatchException e) {
                System.out.println("숫자를 입력해주세요.");
                input = -1;
                continue;
            }
            finally {
                scanner.nextLine();
            }
           
            
            switch (input) {
            case 1:
            	FileIo fileIo = new FileIo(pageManager);
            	fileIo.fileUpLoad();
            	fileIo.insertFileToPage();
            	break;
            	
            case 2: //삭제 안됨 오류수정 필요. //admin user만 삭제가능하게
                System.out.print("삭제할 페이지 ID를 입력하세요: ");
                targetPageId = scanner.nextLong();
                scanner.nextLine();
                pageManager.deletePage(targetPageId);
                break;
            case 3:
            	int select;
            	System.out.print("페이지를 선택하세요: ");
            	try {
                    select = scanner.nextInt();
                }
                catch (InputMismatchException e) {
                    System.out.println("숫자를 입력해주세요.");
                    select = -1;
                    continue;
                }
                finally {
                    scanner.nextLine();
                }
            	Long selectedPageId = indexToPageId.get(select); // page id랑 index 매핑
            	if (selectedPageId != null) {
            	    targetPageId = selectedPageId; // auto-unboxing 안전
            	} else {
            	    System.out.println("잘못된 번호입니다.");
            	    input = -1;
            	    break;
            	}
            	RevisionManager revision = new RevisionManager();
             	try {
             		Connection conn = pageManager.getConnection();
             		revisionList = revision.getRevisionsByPageId(conn, targetPageId);
 				
             	} catch (SQLException e) {
             		System.err.printf("%d 페이지 불러오기 실패\n", targetPageId);
             		e.printStackTrace();
             	}
            	break;
            case 0:
                System.out.println("프로그램을 종료합니다.");
                return;
            default:
                System.out.println("다른 숫자를 입력하세요.");
            }
        } while (input != 0 && input != 3);
        
        
        do {
        	index = 0;
        	revisionList = pageManager.getRevisionsByPageId(targetPageId);
        	for (Page page : pageList) {
        		if (page.getPageId() == targetPageId) {
        			for (Revision rev : revisionList) {
        				if (rev.getPageId() == targetPageId)
        					index++;
        			}
        		}
        	}
        	if (index == 0) { //다른그룹에 해당 페이지 아이디가 존재하더라도 그룹에 없으면 찾지 못하게 하기.
        		System.out.println("그룹에서 해당 페이지를 찾을 수 없습니다.");
        		break;
        	}
        	else {
        		System.out.printf("\nCommit Log | ");
        		for (Page page : pageList) {
            		if (page.getPageId() == targetPageId) {
            			System.out.printf("%s | (%d번 수정됨) |\n", page.getPageName(), index - 1);
            			System.out.printf("---------------------------------------------------\n\n");
            			index = 1;
            			for (Revision rev : revisionList) {
            				indexToRevisionId.put(index, rev.getRevisionId());
            				if (rev.getPageId() == targetPageId)// 작성자 userName으로 바꾸기
            					System.out.printf("%d| (rev ID: %d) | (parent rev ID: %d)\n", index++, rev.getRevisionId(), rev.getParentRevisionId());
            					System.out.printf( "Commit Message: %s | 작성자: %s |\n\n",  rev.getCommitMessage(), 
            							userManager.findUserNameByUserId(rev.getCommittedByUserId()).getUsername());
            			}
            		}
            	}
        	}
    	
        	System.out.println("---------------------------------------------------");
        	System.out.println("1. 수정 파일 업로드");
        	System.out.println("2. 파일 다운로드");
        	System.out.println("3. 파일 미리보기");
        	System.out.println("0. 종료");
        	System.out.println("---------------------------------------------------");
        	System.out.print("메뉴 입력: ");
    	 
    		try {
            	input = scanner.nextInt();
        	}
        	catch (InputMismatchException e) {
            	System.out.println("숫자를 입력해주세요.");
            	input = -1;
            	break;
            	//TODO 페이지 목록으로 돌아가게 만들기
        	}
        	finally {
            	scanner.nextLine();
        	}
    		
    		long parentId = 0;
    		int isExist = 0;
    		FileIo fileIo = new FileIo(pageManager);
    		switch(input) {
    		case 1:
    			System.out.println("parent revision id를 입력하세요(0 입력시 자동지정)");
    			System.out.print(": ");
    			try {
                	parentId = scanner.nextInt();
            	}
            	catch (InputMismatchException e) {
                	System.out.println("숫자를 입력해주세요.");
                	parentId = -1;
                	continue;
                	//TODO 페이지 목록으로 돌아가게 만들기
            	}
            	finally {
                	scanner.nextLine();
            	}
    			if (parentId == 0) { // 0 입력시 자동지정
    				isExist = 1;
    				parentId = pageManager.getLatestRevisionId(targetPageId);
    				fileIo.fileUpLoad();
	            	fileIo.insertFileToRevision(targetPageId, parentId);
    			}
    			else {
    				for (Revision rev : revisionList) {
        				if (rev.getRevisionId() == parentId) {
        					isExist = 1;
        	            	fileIo.fileUpLoad();
        	            	fileIo.insertFileToRevision(targetPageId, parentId);
        	            	break;
        				}
        			}
    			}
    			
    			if (isExist == 0)
    				System.out.println("올바른 parent revision id를 입력하세요.");
    			
            	break;
    		case 2:
    			int select;
    			long revisionId;
    			System.out.print("저장할 리비젼을 선택하세요: ");
    			try {
    				select = scanner.nextInt();
    			}catch (InputMismatchException e) {
    				System.out.println("숫자를 입력하세요.");
    				break;
    			}
    			finally {
    				scanner.nextLine();
    			}
    			Long selectedRevId = indexToRevisionId.get(select); //RevisionList 인덱스랑 revision_id 매핑
    			if (selectedRevId != null) {
            	    revisionId = selectedRevId; // auto-unboxing 안전
            	} else {
            	    System.out.println("잘못된 번호입니다.");
            	    break;
            	}
    			System.out.println("파일을 저장할 위치를 정해주세요.");
    			try {
    				for (Page page: pageList) {
    					if (page.getPageId() == targetPageId) {
    						fileIo.fileDownLoad(pageManager.getConnection(), revisionId, page.getPageName());
    					}
    				}
				} catch (SQLException e) {
					System.err.println("파일을 불러오는 중 오류가 발생했습니다: " + e.getMessage());
					e.printStackTrace();
				}
    			break;
    		case 3:
    			//TODO 리비젼아이디에 대당하는 파일 불러와서 보여주기
    			//1. 확장자 검사(소스파일만 가능하도록)
    			//2. byte[]로 파일데이터 불러오기
    			//3. 소스파일이라면 UTF-8로 대부분 인코딩 되어있으므로 파일데이터 String 으로 복원가능. 
    			//4. 에러나면 UTF-8 메시지 띄우기
    		case 0:
    			System.out.println("프로그램을 종료합니다.");
    			return;
    		default:	
            	System.out.println("올바른 숫자를 입력하세요.");
    		}
    	} while (input != 0);
    
    	scanner.close(); // 스캐너 자원 해제
    }
}