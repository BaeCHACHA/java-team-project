package java_team_project;

import java.util.Scanner;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
//import java.sql.Connection;
//import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

public class FileIo {
	private String pageName;
	private String filePath;
	private PageManager pageManager;
	private String commitMessage;
	private Scanner scanner = new Scanner(System.in);
	
	public FileIo(PageManager pagemanager) {
		this.pageManager = pagemanager;
		this.pageName = null;
		this.filePath = null;
		this.commitMessage = null;
	}
	
	public void fileUpLoad() {
		JFrame frame = new JFrame();
    	frame.setAlwaysOnTop(true);
    	JFileChooser chooser = new JFileChooser();
    	chooser.setDialogTitle("파일탐색기");
    	// filter에 java c 외 추가 소스코드 확장자 강제 가능
    	FileNameExtensionFilter filter = new FileNameExtensionFilter("소스코드 및 텍스트 파일 (*.txt, *.java, *.c)", "txt", "java", "c");
        chooser.setFileFilter(filter);
        chooser.setAcceptAllFileFilterUsed(false); // 필터 확장자 말고 선택할 수 없도록
        
        int result = chooser.showOpenDialog(frame);
    	
    	if (result == JFileChooser.APPROVE_OPTION) {
    		File file = chooser.getSelectedFile();
    		JOptionPane.showMessageDialog(null, "선택한 파일: " + file.getAbsolutePath());
    		
    		pageName = file.getName();
    		filePath = file.getPath();
    		
    	}
	}
	
	public void fileDownLoad(Connection conn, long revisionId, String pageName) {
		String sql = "SELECT content FROM file_data WHERE actual_data_id = ?";
		long actualDataId = revisionId; //DB 구조상 항상 actual_data_id랑 revision_id의 값은 같음
		byte[] fileData = null;
		ResultSet rs = null;
		try (PreparedStatement pstmt = conn.prepareStatement(sql)){
			pstmt.setLong(1, actualDataId);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				fileData = rs.getBytes("content");
			}
		}  catch (SQLException e) {
            System.err.println("파일을 불러오는 중 오류가 발생했습니다: " + e.getMessage());
            e.printStackTrace();
            return;
        }
		finally {
			if (fileData == null) {
				System.out.println("파일을 찾을 수 없습니다");
				return;
			}
		}
		
		try {
			String extenstion = getFileExtension(pageName);
			JFrame frame = new JFrame();
			frame.setAlwaysOnTop(true);
			JFileChooser chooser = new JFileChooser();
			chooser.setDialogTitle("저장할 파일 위치 선택");
			FileNameExtensionFilter filter = new FileNameExtensionFilter("*." + extenstion + " 파일", extenstion);
			chooser.setFileFilter(filter);
			chooser.setAcceptAllFileFilterUsed(false); // 필터 확장자 말고 선택할 수 없도록
			
			int result = chooser.showOpenDialog(frame);
	    	
	    	if (result == JFileChooser.APPROVE_OPTION) {
	    		File savedFile = chooser.getSelectedFile();
	    		String savedFilePath = savedFile.getAbsolutePath();
	    		JOptionPane.showMessageDialog(null, savedFilePath + "위치에 파일이 저장됩니다.");
	    		if(!savedFilePath.endsWith("." + extenstion)) { // 확장자 없는경우 자동 추가
	    			savedFilePath += "." + extenstion;
	    		}
	    		Files.write(Paths.get(savedFilePath), fileData);
	    		System.out.println("파일을 성공적으로 저장했습니다!");
	    	}
		} catch(IOException e) {
			e.printStackTrace();
			System.out.println("파일 저장중 오류가 발생했습니다.");
			return;
		}
		
	}
	
	public void insertFileToPage() {
    	if (filePath != null) {
    		System.out.println("파일 불러오기 성공!");
    		System.out.print("초기 커밋 메시지를 입력하세요: ");
    		commitMessage = scanner.nextLine();
              
            try {
                  // 파일 내용을 byte[]로 읽어오는 헬퍼 메소드 호출
                byte[] fileContent = readFileContent(filePath);

                if (fileContent != null) {
                      // makePage 메소드 호출 (groupManager가 아닌 pageManager 사용)
                      // makePage는 pageManager의 메소드입니다.
                    long createdPageId = pageManager.makePage(pageName, fileContent, commitMessage);

                    if (createdPageId != -1) { // makePage는 성공 시 page_id 반환
                        System.out.println("페이지 생성 성공! 페이지 ID: " + createdPageId);
                    } else {
                        System.out.println("페이지 생성 실패."); // makePage 내부에서 오류 메시지 출력됨
                    }
                } else {
                    System.out.println("파일을 읽어오는데 실패했습니다. 경로를 확인하세요.");
                }

            } catch (IOException e) {
                  // readFileContent에서 발생한 예외 처리
                System.err.println("파일 읽기 오류: " + e.getMessage());
                e.printStackTrace();
                System.out.println("페이지 생성 실패 (파일 읽기 오류).");
            }
    	}
    	else {
    		System.out.println("파일을 읽어오는데 실패했습니다.");
    	}
	}
	
	public void insertFileToRevision(long pageId, long parentId) {
		if (filePath != null) {
    		System.out.println("파일 불러오기 성공!");
    		System.out.print("커밋 메시지를 입력하세요: ");
    		commitMessage = scanner.nextLine();
    		
    		try {
    			  // 파일 내용을 byte[]로 읽어오는 헬퍼 메소드 호출
                byte[] fileContent = readFileContent(filePath);
                
                if (fileContent != null) {
						pageManager.insertRevision(pageId, parentId, fileContent, commitMessage);
                }
    		} catch (IOException e) {
    			  // readFileContent에서 발생한 예외 처리
                System.err.println("파일 읽기 오류: " + e.getMessage());
                e.printStackTrace();
                System.out.println("Revision 생성 실패 (파일 읽기 오류).");
    		}
		}
		else {
    		System.out.println("파일을 읽어오는데 실패했습니다.");
    	}
	}
	
	
	/**
	 * 확장자를 추출하는 메서드
	 * @param pageName 페이지 이름에서 확장자를 추출
	 * @return 확장자 반환 ex) java, c, py, cpp ...
	 */
	public String getFileExtension(String pageName) {
		String extenstion = "";
		int tokens = pageName.lastIndexOf(".");
		if (tokens != -1 && tokens < pageName.length() - 1) {
			extenstion = pageName.substring(tokens + 1);
		}
		
		return extenstion;
	}
	
	
	private static byte[] readFileContent(String filePath) throws IOException {
       // java.nio.file.Files를 사용하여 파일 내용을 쉽게 읽습니다.
       // Paths.get() 메소드로 문자열 경로를 Path 객체로 변환합니다.
       try {
           return Files.readAllBytes(Paths.get(filePath));
       } catch (IOException e) {
           // 파일이 없거나, 권한이 없거나, 읽기 오류 등 발생 시
           System.err.println("Error reading file: " + e.getMessage());
           e.printStackTrace();
           throw e; // 예외를 잡아서 메시지 출력 후 다시 던져서 호출부에서 처리하도록 함
           // 또는 단순히 null을 반환하고 호출부에서 null 체크
           // return null; // 이 경우 catch 블록에서 throw e; 대신 이 줄 사용
       }
    }
	
	public String getPageName() {
		return pageName;
	}
	public String getFilePath() {
		return filePath;
	}
	public String getCommitMessage() {
		return commitMessage;
	}
}
