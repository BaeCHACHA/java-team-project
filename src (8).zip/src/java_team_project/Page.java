package java_team_project;

import java.sql.Timestamp;

public class Page {
    private final long pageId;
    private final long groupId;
    private final String pageName;
    private final Timestamp createdAt;
    private final long latestRevisionId;

    public Page(long pageId, long groupId, String pageName, Timestamp createdAt, long latestRevisionId) {
        this.pageId = pageId;
        this.groupId = groupId;
        this.pageName = pageName;
        this.createdAt = createdAt;
        this.latestRevisionId = latestRevisionId;
    }

    public long getPageId() { return pageId; }

    public long getGroupId() { return groupId; }

    public String getPageName() { return pageName; }

    public Timestamp getCreatedAt() { return createdAt; }

    public long getLatestRevisionId() { return latestRevisionId; }

    @Override
    public String toString() {
        return "Page{" +
                "PageId=" + pageId +
                ", GroupId=" + groupId +
                ", PageName='" + pageName + '\'' +
                ", CreatedAt=" + createdAt +
                ", latestRevisionId=" + latestRevisionId +
                '}';
    }
}
