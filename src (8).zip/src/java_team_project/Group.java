package java_team_project;

import java.sql.Timestamp;

public class Group {
    private final long groupId;
    private final String groupName;
    private final String joinKey;
    private final long createdByUserId;
    private final Timestamp createdAt;

    public Group(long groupId, String groupName, String joinKey, long createdByUserId, Timestamp createdAt) {
        this.createdAt = createdAt;
        this.groupName = groupName;
        this.joinKey = joinKey;
        this.createdByUserId = createdByUserId;
        this.groupId = groupId;
    }

    public long getGroupId() { return groupId; }

    public String getGroupName() { return groupName; }

    public String getJoinKey() { return joinKey; }

    public long getCreatedByUserId() { return createdByUserId; }

    public Timestamp getCreatedAt() { return createdAt; }

    @Override
    public String toString() {
        return "Group{" +
                "GroupId=" + groupId +
                ", GroupName='" + groupName + '\'' +
                ", JoinKey='" + joinKey + '\'' +
                ", CreatedByUserId=" + createdByUserId +
                ", CreatedAt=" + createdAt +
                '}';
    }
}
