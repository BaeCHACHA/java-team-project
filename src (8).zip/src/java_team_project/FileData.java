package java_team_project;

import java.sql.Timestamp;

public class FileData {
    private final long actualDataId;
    private final byte[] content;
    private final String checksum;
    private final Timestamp createdAt;

    public FileData(long actualDataId, byte[] content, String checksum, Timestamp createdAt) {
        this.actualDataId = actualDataId;
        this.content = content;
        this.checksum = checksum;
        this.createdAt = createdAt;
    }

    public long getActualDataId() { return actualDataId; }

    public byte[] getContent() { return content; }

    public String getChecksum() { return checksum; }

    public Timestamp getCreatedAt() { return createdAt; }

    @Override
    public String toString() {
        return "FileData{" +
                "actualDataId=" + actualDataId +
                ", checksum='" + checksum + '\'' +
                ", createdAt=" + createdAt +
                '}';
    }
}