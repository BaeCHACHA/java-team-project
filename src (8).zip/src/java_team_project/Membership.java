package java_team_project;

public class Membership {
    private final long groupId;
    private final long userId;
    private final String userRole;

    Membership(long groupId, long userId, String userRole) {
        this.groupId = groupId;
        this.userId = userId;
        this.userRole = userRole;
    }

    public long getGroupId() { return groupId; }

    public long getUserId() { return userId; }

    public String getUserRole() { return userRole; }

    @Override
    public String toString() {
        return "Group{" +
                "GroupId=" + groupId +
                "UserId=" + userId +
                ", GroupName='" + userRole + '\'' +
                '}';
    }
}
